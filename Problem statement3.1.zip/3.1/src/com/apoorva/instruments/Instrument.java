package com.apoorva.instruments;

public abstract class Instrument {
	public abstract void play();
}
